import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import PlantDetails from './pages/PlantDetails';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';
import { PlantProvider } from './context/PlantContext';

function App() {
  return (
    <PlantProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/plant/:id" element={<PlantDetails />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </Router>
    </PlantProvider>
  );
}

export default App;
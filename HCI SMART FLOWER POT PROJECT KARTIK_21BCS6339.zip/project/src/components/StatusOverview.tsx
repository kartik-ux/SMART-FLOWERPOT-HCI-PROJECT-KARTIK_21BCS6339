import React from 'react';
import { Droplets, Thermometer, Sun, Battery } from 'lucide-react';

const StatusOverview: React.FC = () => {
  const statusItems = [
    {
      title: 'Water Level',
      icon: <Droplets size={24} className="text-blue-500" />,
      value: '75%',
      status: 'good',
      description: 'Tank capacity: 2.5L',
    },
    {
      title: 'Temperature',
      icon: <Thermometer size={24} className="text-red-500" />,
      value: '23°C',
      status: 'good',
      description: 'Indoor: Optimal range',
    },
    {
      title: 'Light Intensity',
      icon: <Sun size={24} className="text-amber-500" />,
      value: '65%',
      status: 'good',
      description: 'LED light: Auto mode',
    },
    {
      title: 'Battery',
      icon: <Battery size={24} className="text-green-500" />,
      value: '90%',
      status: 'good',
      description: 'Solar charging',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {statusItems.map((item) => (
        <div key={item.title} className="bg-white rounded-lg shadow-sm p-4">
          <div className="flex items-center mb-2">
            {item.icon}
            <h3 className="font-medium text-gray-700 ml-2">{item.title}</h3>
          </div>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-2xl font-semibold text-gray-800">{item.value}</p>
              <p className="text-xs text-gray-500">{item.description}</p>
            </div>
            <div className={`px-2 py-1 rounded-full text-xs font-medium ${
              item.status === 'good' ? 'bg-green-100 text-green-700' : 
              item.status === 'warning' ? 'bg-yellow-100 text-yellow-700' : 
              'bg-red-100 text-red-700'
            }`}>
              {item.status === 'good' ? 'Good' : 
               item.status === 'warning' ? 'Warning' : 'Alert'}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatusOverview;
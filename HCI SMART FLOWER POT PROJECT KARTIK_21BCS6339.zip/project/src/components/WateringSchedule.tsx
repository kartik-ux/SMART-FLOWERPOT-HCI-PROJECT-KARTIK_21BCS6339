import React, { useState } from 'react';
import { Calendar, Droplets, Clock, Plus, Save, X } from 'lucide-react';
import { Schedule } from '../types';

interface WateringScheduleProps {
  schedule: Schedule[];
}

const WateringSchedule: React.FC<WateringScheduleProps> = ({ schedule }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newDay, setNewDay] = useState('');
  const [newTime, setNewTime] = useState('');
  
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  const handleAddClick = () => {
    setIsAdding(true);
    setNewDay(daysOfWeek[0]);
    setNewTime('08:00');
  };

  const handleSave = () => {
    // In a real application, this would call a function from context to add to the schedule
    setIsAdding(false);
  };

  const handleCancel = () => {
    setIsAdding(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Droplets size={20} className="text-blue-500 mr-2" />
          <h2 className="font-semibold text-gray-800">Watering Schedule</h2>
        </div>
        {!isAdding && (
          <button 
            onClick={handleAddClick}
            className="inline-flex items-center text-sm font-medium text-green-600 hover:text-green-700"
          >
            <Plus size={16} className="mr-1" />
            Add Schedule
          </button>
        )}
      </div>
      
      <div className="space-y-3">
        {schedule.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
            <div className="flex items-center">
              <Calendar size={16} className="text-gray-500 mr-2" />
              <span className="text-sm text-gray-700">{item.day}</span>
            </div>
            <div className="flex items-center">
              <Clock size={16} className="text-gray-500 mr-2" />
              <span className="text-sm text-gray-700">{item.time}</span>
            </div>
            <div className={`px-2 py-1 rounded-full text-xs ${
              item.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
            }`}>
              {item.active ? 'Active' : 'Inactive'}
            </div>
          </div>
        ))}
        
        {isAdding && (
          <div className="p-3 bg-blue-50 rounded-md">
            <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-3 sm:space-y-0">
              <div className="flex flex-col sm:flex-row sm:items-center flex-1 space-y-3 sm:space-y-0 sm:space-x-4">
                <div className="flex-1">
                  <label htmlFor="day" className="block text-xs text-gray-500 mb-1">Day</label>
                  <select 
                    id="day"
                    value={newDay} 
                    onChange={(e) => setNewDay(e.target.value)}
                    className="w-full text-sm rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
                  >
                    {daysOfWeek.map(day => (
                      <option key={day} value={day}>{day}</option>
                    ))}
                  </select>
                </div>
                <div className="flex-1">
                  <label htmlFor="time" className="block text-xs text-gray-500 mb-1">Time</label>
                  <input 
                    id="time"
                    type="time" 
                    value={newTime} 
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full text-sm rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
                  />
                </div>
              </div>
              <div className="flex space-x-2 justify-end">
                <button 
                  onClick={handleCancel}
                  className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                >
                  <X size={16} className="mr-1" />
                  Cancel
                </button>
                <button 
                  onClick={handleSave}
                  className="inline-flex items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none"
                >
                  <Save size={16} className="mr-1" />
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WateringSchedule;
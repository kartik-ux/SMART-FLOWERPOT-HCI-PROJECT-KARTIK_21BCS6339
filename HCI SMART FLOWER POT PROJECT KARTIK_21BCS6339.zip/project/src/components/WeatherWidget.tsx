import React from 'react';
import { Cloud, Droplets, Wind, Sun } from 'lucide-react';

const WeatherWidget: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Local Weather</h2>
        <span className="text-sm text-gray-500">San Francisco</span>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Cloud size={36} className="text-blue-400 mr-3" />
          <div>
            <p className="text-3xl font-bold text-gray-800">21°C</p>
            <p className="text-sm text-gray-500">Partly Cloudy</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="flex items-center justify-end mb-1">
            <Droplets size={14} className="text-blue-500 mr-1" />
            <span className="text-sm text-gray-600">45% Humidity</span>
          </div>
          <div className="flex items-center justify-end">
            <Wind size={14} className="text-gray-500 mr-1" />
            <span className="text-sm text-gray-600">8 km/h Wind</span>
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-3 border-t border-gray-100">
        <div className="flex justify-between">
          <div className="text-center">
            <p className="text-xs text-gray-500">Mon</p>
            <Cloud size={16} className="text-blue-400 mx-auto my-1" />
            <p className="text-xs font-medium">20°</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Tue</p>
            <Cloud size={16} className="text-blue-400 mx-auto my-1" />
            <p className="text-xs font-medium">22°</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Wed</p>
            <Sun size={16} className="text-amber-400 mx-auto my-1" />
            <p className="text-xs font-medium">24°</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Thu</p>
            <Sun size={16} className="text-amber-400 mx-auto my-1" />
            <p className="text-xs font-medium">25°</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-500">Fri</p>
            <Cloud size={16} className="text-blue-400 mx-auto my-1" />
            <p className="text-xs font-medium">21°</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherWidget;
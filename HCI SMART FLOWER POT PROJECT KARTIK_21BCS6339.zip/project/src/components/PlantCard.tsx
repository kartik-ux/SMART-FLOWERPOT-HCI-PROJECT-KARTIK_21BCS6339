import React from 'react';
import { Link } from 'react-router-dom';
import { Droplets, Thermometer, Sun, Activity } from 'lucide-react';
import { Plant } from '../types';

interface PlantCardProps {
  plant: Plant;
}

const PlantCard: React.FC<PlantCardProps> = ({ plant }) => {
  const getMoistureColor = (level: number) => {
    if (level < 30) return 'text-red-500';
    if (level < 60) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getLightColor = (level: number) => {
    if (level < 30) return 'text-blue-500';
    if (level < 70) return 'text-yellow-500';
    return 'text-orange-500';
  };

  return (
    <Link to={`/plant/${plant.id}`} className="block">
      <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-4 h-full flex flex-col">
        <div className="relative mb-3">
          <img
            src={plant.imageUrl}
            alt={plant.name}
            className="w-full h-48 object-cover rounded-md"
          />
          <div className={`absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-medium ${
            plant.status === 'healthy' ? 'bg-green-100 text-green-700' : 
            plant.status === 'warning' ? 'bg-yellow-100 text-yellow-700' : 
            'bg-red-100 text-red-700'
          }`}>
            {plant.status === 'healthy' ? 'Healthy' : 
             plant.status === 'warning' ? 'Needs Attention' : 'Critical'}
          </div>
        </div>
        
        <h3 className="font-semibold text-gray-800 text-lg mb-1">{plant.name}</h3>
        <p className="text-gray-500 text-sm mb-3">{plant.species}</p>
        
        <div className="grid grid-cols-2 gap-2 mt-auto">
          <div className="flex items-center">
            <Droplets size={16} className={getMoistureColor(plant.moisture)} />
            <span className="ml-2 text-sm">{plant.moisture}%</span>
          </div>
          <div className="flex items-center">
            <Thermometer size={16} className="text-red-400" />
            <span className="ml-2 text-sm">{plant.temperature}°C</span>
          </div>
          <div className="flex items-center">
            <Sun size={16} className={getLightColor(plant.light)} />
            <span className="ml-2 text-sm">{plant.light}%</span>
          </div>
          <div className="flex items-center">
            <Activity size={16} className="text-purple-500" />
            <span className="ml-2 text-sm">{plant.health}%</span>
          </div>
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between items-center">
          <div className="flex items-center">
            <div className={`w-2 h-2 rounded-full mr-2 ${
              plant.wateringStatus === 'auto' ? 'bg-green-500' : 'bg-gray-400'
            }`}></div>
            <span className="text-xs text-gray-500">
              {plant.wateringStatus === 'auto' ? 'Auto-Watering' : 'Manual Watering'}
            </span>
          </div>
          <span className="text-xs text-gray-500">Last watered {plant.lastWatered}</span>
        </div>
      </div>
    </Link>
  );
};

export default PlantCard;
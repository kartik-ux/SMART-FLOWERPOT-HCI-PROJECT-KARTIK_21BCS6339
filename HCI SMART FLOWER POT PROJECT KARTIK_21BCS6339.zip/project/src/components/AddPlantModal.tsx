import React, { useState } from 'react';
import { X } from 'lucide-react';
import { usePlantContext } from '../context/PlantContext';
import { Plant } from '../types';

interface AddPlantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddPlantModal: React.FC<AddPlantModalProps> = ({ isOpen, onClose }) => {
  const { addPlant } = usePlantContext();
  const [formData, setFormData] = useState({
    name: '',
    species: '',
    imageUrl: 'https://images.pexels.com/photos/3097770/pexels-photo-3097770.jpeg',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newPlant: Plant = {
      id: crypto.randomUUID(),
      ...formData,
      moisture: 65,
      temperature: 22,
      light: 75,
      health: 90,
      status: 'healthy',
      wateringStatus: 'auto',
      lastWatered: 'Just now',
      activities: [],
      wateringSchedule: [
        { day: 'Monday', time: '08:00 AM', active: true },
        { day: 'Thursday', time: '08:00 AM', active: true },
      ],
      environmentData: [
        { day: 'Mon', moisture: 65, temperature: 22, light: 75 },
        { day: 'Tue', moisture: 65, temperature: 22, light: 75 },
        { day: 'Wed', moisture: 65, temperature: 22, light: 75 },
        { day: 'Thu', moisture: 65, temperature: 22, light: 75 },
        { day: 'Fri', moisture: 65, temperature: 22, light: 75 },
        { day: 'Sat', moisture: 65, temperature: 22, light: 75 },
        { day: 'Sun', moisture: 65, temperature: 22, light: 75 },
      ],
    };

    addPlant(newPlant);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Add New Plant</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Plant Name
            </label>
            <input
              type="text"
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label htmlFor="species" className="block text-sm font-medium text-gray-700">
              Species
            </label>
            <input
              type="text"
              id="species"
              value={formData.species}
              onChange={(e) => setFormData({ ...formData, species: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label htmlFor="imageUrl" className="block text-sm font-medium text-gray-700">
              Image URL
            </label>
            <input
              type="url"
              id="imageUrl"
              value={formData.imageUrl}
              onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Add Plant
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPlantModal;
import React from 'react';
import Sidebar from './Sidebar';
import MobileNav from './MobileNav';
import { Leaf } from 'lucide-react';
import { Link } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="flex flex-col md:flex-row">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar />
        </div>
        
        {/* Mobile Header */}
        <div className="md:hidden bg-white shadow-sm">
          <div className="flex items-center justify-between px-4 py-3">
            <Link to="/" className="flex items-center space-x-2">
              <Leaf className="h-6 w-6 text-green-600" />
              <span className="font-semibold text-lg text-gray-800">SmartPlanter</span>
            </Link>
            <MobileNav />
          </div>
        </div>
        
        {/* Main Content */}
        <main className="flex-1 p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
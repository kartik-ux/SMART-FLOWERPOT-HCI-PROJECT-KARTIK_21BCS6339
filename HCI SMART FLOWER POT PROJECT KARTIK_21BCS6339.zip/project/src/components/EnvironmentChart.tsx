import React from 'react';
import { EnvironmentData } from '../types';

interface EnvironmentChartProps {
  data: EnvironmentData[];
}

const EnvironmentChart: React.FC<EnvironmentChartProps> = ({ data }) => {
  // In a real application, we would use a proper charting library like Chart.js, Recharts, etc.
  // For now, we'll create a simple visual representation of the data
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <h2 className="font-semibold text-gray-800 mb-4">Environment Trends</h2>
      
      <div className="space-y-6">
        {/* Moisture Chart */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-700">Moisture Levels</h3>
            <div className="text-xs text-gray-500">Last 7 days</div>
          </div>
          <div className="h-16 bg-blue-50 rounded-md overflow-hidden relative">
            <div className="absolute inset-0 flex items-end">
              {data.map((item, index) => (
                <div 
                  key={index} 
                  className="flex-1 bg-blue-400 opacity-80"
                  style={{ 
                    height: `${item.moisture}%`,
                    margin: '0 1px',
                  }}
                ></div>
              ))}
            </div>
          </div>
          <div className="flex justify-between mt-1">
            {data.map((item, index) => (
              <div key={index} className="text-xs text-gray-500">{item.day}</div>
            ))}
          </div>
        </div>
        
        {/* Temperature Chart */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-700">Temperature</h3>
            <div className="text-xs text-gray-500">Last 7 days</div>
          </div>
          <div className="h-16 bg-red-50 rounded-md overflow-hidden relative">
            <div className="absolute inset-0 flex items-end">
              {data.map((item, index) => {
                const height = (item.temperature / 30) * 100; // Assuming max temp is 30°C
                return (
                  <div 
                    key={index} 
                    className="flex-1 bg-red-400 opacity-80"
                    style={{ 
                      height: `${height}%`,
                      margin: '0 1px',
                    }}
                  ></div>
                );
              })}
            </div>
          </div>
          <div className="flex justify-between mt-1">
            {data.map((item, index) => (
              <div key={index} className="text-xs text-gray-500">{item.day}</div>
            ))}
          </div>
        </div>
        
        {/* Light Chart */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-700">Light Intensity</h3>
            <div className="text-xs text-gray-500">Last 7 days</div>
          </div>
          <div className="h-16 bg-amber-50 rounded-md overflow-hidden relative">
            <div className="absolute inset-0 flex items-end">
              {data.map((item, index) => (
                <div 
                  key={index} 
                  className="flex-1 bg-amber-400 opacity-80"
                  style={{ 
                    height: `${item.light}%`,
                    margin: '0 1px',
                  }}
                ></div>
              ))}
            </div>
          </div>
          <div className="flex justify-between mt-1">
            {data.map((item, index) => (
              <div key={index} className="text-xs text-gray-500">{item.day}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnvironmentChart;
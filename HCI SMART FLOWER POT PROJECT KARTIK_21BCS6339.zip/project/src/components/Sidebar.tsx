import React from 'react';
import { NavLink } from 'react-router-dom';
import { Leaf, Home, Droplets, Settings, BarChart2, Info } from 'lucide-react';

const Sidebar: React.FC = () => {
  const navItems = [
    { name: 'Dashboard', icon: <Home size={20} />, path: '/' },
    { name: 'Water Control', icon: <Droplets size={20} />, path: '/water-control' },
    { name: 'Analytics', icon: <BarChart2 size={20} />, path: '/analytics' },
    { name: 'Settings', icon: <Settings size={20} />, path: '/settings' },
    { name: 'About', icon: <Info size={20} />, path: '/about' },
  ];

  return (
    <div className="h-screen w-64 bg-white shadow-md flex flex-col">
      <div className="p-5">
        <div className="flex items-center space-x-3">
          <Leaf className="h-8 w-8 text-green-600" />
          <h1 className="text-xl font-bold text-gray-800">SmartPlanter</h1>
        </div>
      </div>
      
      <nav className="flex-1 mt-6">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.name}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center px-5 py-3 transition-colors ${
                    isActive
                      ? 'bg-green-50 text-green-700 border-r-4 border-green-600'
                      : 'text-gray-600 hover:bg-green-50 hover:text-green-700'
                  }`
                }
              >
                <span className="mr-3">{item.icon}</span>
                {item.name}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-5 border-t border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
            <Leaf className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <p className="font-medium text-gray-700">Plant Lover</p>
            <p className="text-xs text-gray-500">4 Plants Connected</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
import React, { createContext, useContext, useState } from 'react';
import { Plant, Activity, Schedule, EnvironmentData } from '../types';

// Sample data
const samplePlants: Plant[] = [
  {
    id: '1',
    name: 'Monstera Deliciosa',
    species: 'Monstera Deliciosa',
    imageUrl: 'https://images.pexels.com/photos/3097770/pexels-photo-3097770.jpeg',
    moisture: 65,
    temperature: 22,
    light: 75,
    health: 90,
    status: 'healthy',
    wateringStatus: 'auto',
    lastWatered: '2 days ago',
    activities: [
      { type: 'watering', description: 'Automatic watering completed', date: 'May 15, 2025', time: '09:30 AM' },
      { type: 'light', description: 'Light turned on automatically', date: 'May 15, 2025', time: '06:00 AM' },
      { type: 'system', description: 'System check completed', date: 'May 14, 2025', time: '11:45 PM' },
    ],
    wateringSchedule: [
      { day: 'Monday', time: '08:00 AM', active: true },
      { day: 'Thursday', time: '08:00 AM', active: true },
      { day: 'Saturday', time: '10:00 AM', active: false },
    ],
    environmentData: [
      { day: 'Mon', moisture: 60, temperature: 21, light: 70 },
      { day: 'Tue', moisture: 55, temperature: 22, light: 75 },
      { day: 'Wed', moisture: 45, temperature: 23, light: 80 },
      { day: 'Thu', moisture: 70, temperature: 22, light: 65 },
      { day: 'Fri', moisture: 65, temperature: 21, light: 60 },
      { day: 'Sat', moisture: 60, temperature: 20, light: 55 },
      { day: 'Sun', moisture: 55, temperature: 21, light: 70 },
    ]
  },
  {
    id: '2',
    name: 'Peace Lily',
    species: 'Spathiphyllum',
    imageUrl: 'https://images.pexels.com/photos/1084199/pexels-photo-1084199.jpeg',
    moisture: 40,
    temperature: 21,
    light: 60,
    health: 75,
    status: 'warning',
    wateringStatus: 'manual',
    lastWatered: '5 days ago',
    activities: [
      { type: 'system', description: 'Low moisture warning', date: 'May 15, 2025', time: '10:15 AM' },
      { type: 'light', description: 'Light turned on automatically', date: 'May 15, 2025', time: '06:00 AM' },
      { type: 'watering', description: 'Manual watering logged', date: 'May 10, 2025', time: '02:30 PM' },
    ],
    wateringSchedule: [
      { day: 'Tuesday', time: '08:00 AM', active: true },
      { day: 'Friday', time: '08:00 AM', active: true },
    ],
    environmentData: [
      { day: 'Mon', moisture: 55, temperature: 21, light: 65 },
      { day: 'Tue', moisture: 50, temperature: 22, light: 60 },
      { day: 'Wed', moisture: 45, temperature: 21, light: 65 },
      { day: 'Thu', moisture: 40, temperature: 22, light: 60 },
      { day: 'Fri', moisture: 35, temperature: 21, light: 55 },
      { day: 'Sat', moisture: 30, temperature: 22, light: 60 },
      { day: 'Sun', moisture: 40, temperature: 21, light: 65 },
    ]
  },
  {
    id: '3',
    name: 'Snake Plant',
    species: 'Sansevieria Trifasciata',
    imageUrl: 'https://images.pexels.com/photos/2123482/pexels-photo-2123482.jpeg',
    moisture: 80,
    temperature: 24,
    light: 45,
    health: 95,
    status: 'healthy',
    wateringStatus: 'auto',
    lastWatered: '10 days ago',
    activities: [
      { type: 'system', description: 'System check completed', date: 'May 14, 2025', time: '11:45 PM' },
      { type: 'light', description: 'Light adjusted to 40%', date: 'May 14, 2025', time: '02:00 PM' },
      { type: 'watering', description: 'Automatic watering completed', date: 'May 5, 2025', time: '09:30 AM' },
    ],
    wateringSchedule: [
      { day: 'Monday', time: '08:00 AM', active: true, every: '2 weeks' },
    ],
    environmentData: [
      { day: 'Mon', moisture: 80, temperature: 23, light: 45 },
      { day: 'Tue', moisture: 78, temperature: 24, light: 50 },
      { day: 'Wed', moisture: 76, temperature: 24, light: 45 },
      { day: 'Thu', moisture: 74, temperature: 25, light: 40 },
      { day: 'Fri', moisture: 72, temperature: 24, light: 45 },
      { day: 'Sat', moisture: 70, temperature: 23, light: 50 },
      { day: 'Sun', moisture: 82, temperature: 24, light: 45 },
    ]
  }
];

interface PlantContextType {
  plants: Plant[];
  getPlantById: (id: string) => Plant | undefined;
  addPlant: (plant: Plant) => void;
  updatePlant: (id: string, data: Partial<Plant>) => void;
  deletePlant: (id: string) => void;
}

const PlantContext = createContext<PlantContextType | undefined>(undefined);

export const PlantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [plants, setPlants] = useState<Plant[]>(samplePlants);

  const getPlantById = (id: string) => {
    return plants.find(plant => plant.id === id);
  };

  const addPlant = (plant: Plant) => {
    setPlants(prevPlants => [...prevPlants, plant]);
  };

  const updatePlant = (id: string, data: Partial<Plant>) => {
    setPlants(prevPlants => 
      prevPlants.map(plant => 
        plant.id === id ? { ...plant, ...data } : plant
      )
    );
  };

  const deletePlant = (id: string) => {
    setPlants(prevPlants => prevPlants.filter(plant => plant.id !== id));
  };

  return (
    <PlantContext.Provider value={{ plants, getPlantById, addPlant, updatePlant, deletePlant }}>
      {children}
    </PlantContext.Provider>
  );
};

export const usePlantContext = () => {
  const context = useContext(PlantContext);
  if (context === undefined) {
    throw new Error('usePlantContext must be used within a PlantProvider');
  }
  return context;
};
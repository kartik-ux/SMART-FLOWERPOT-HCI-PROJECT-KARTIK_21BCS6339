import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { usePlantContext } from '../context/PlantContext';
import { ArrowLeft, Droplets, Thermometer, Sun, Activity, AlertTriangle, Calendar, Clock, ChevronRight } from 'lucide-react';
import WateringSchedule from '../components/WateringSchedule';
import EnvironmentChart from '../components/EnvironmentChart';

const PlantDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getPlantById } = usePlantContext();
  const [plant, setPlant] = useState(getPlantById(id || ''));
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'settings'>('overview');

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'settings', label: 'Settings' },
  ];

  if (!plant) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <AlertTriangle size={48} className="text-amber-500 mb-4" />
        <h2 className="text-xl font-semibold text-gray-800">Plant Not Found</h2>
        <p className="text-gray-600 mb-4">The plant you're looking for doesn't exist or has been removed.</p>
        <Link 
          to="/" 
          className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to Dashboard
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <Link to="/" className="inline-flex items-center text-green-600 hover:text-green-700 font-medium">
          <ArrowLeft size={16} className="mr-1" />
          Back to Dashboard
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="relative h-48 md:h-64">
          <img 
            src={plant.imageUrl} 
            alt={plant.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-6">
            <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mb-2 self-start ${
              plant.status === 'healthy' ? 'bg-green-100 text-green-700' : 
              plant.status === 'warning' ? 'bg-yellow-100 text-yellow-700' : 
              'bg-red-100 text-red-700'
            }`}>
              {plant.status === 'healthy' ? 'Healthy' : 
               plant.status === 'warning' ? 'Needs Attention' : 'Critical'}
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">{plant.name}</h1>
            <p className="text-white/80">{plant.species}</p>
          </div>
        </div>

        <div className="border-b border-gray-200">
          <nav className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-4 px-6 font-medium text-sm focus:outline-none ${
                  activeTab === tab.id 
                    ? 'text-green-600 border-b-2 border-green-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <Droplets size={24} className="text-blue-500" />
                    <h3 className="ml-2 font-medium text-gray-700">Moisture</h3>
                  </div>
                  <p className="mt-2 text-2xl font-semibold">{plant.moisture}%</p>
                  <p className="text-xs text-gray-500">Last updated: 10 min ago</p>
                </div>
                <div className="bg-red-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <Thermometer size={24} className="text-red-500" />
                    <h3 className="ml-2 font-medium text-gray-700">Temperature</h3>
                  </div>
                  <p className="mt-2 text-2xl font-semibold">{plant.temperature}°C</p>
                  <p className="text-xs text-gray-500">Optimal: 18-24°C</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <Sun size={24} className="text-amber-500" />
                    <h3 className="ml-2 font-medium text-gray-700">Light</h3>
                  </div>
                  <p className="mt-2 text-2xl font-semibold">{plant.light}%</p>
                  <p className="text-xs text-gray-500">LED: Auto mode</p>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex items-center">
                    <Activity size={24} className="text-purple-500" />
                    <h3 className="ml-2 font-medium text-gray-700">Health</h3>
                  </div>
                  <p className="mt-2 text-2xl font-semibold">{plant.health}%</p>
                  <p className="text-xs text-gray-500">Based on all metrics</p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-semibold text-gray-800">Recent Activity</h2>
                  <button className="text-green-600 text-sm font-medium hover:text-green-700 flex items-center">
                    View All <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
                
                <div className="space-y-3">
                  {plant.activities.map((activity, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`mt-1 p-1 rounded-full ${
                        activity.type === 'watering' ? 'bg-blue-100' :
                        activity.type === 'light' ? 'bg-amber-100' :
                        'bg-gray-100'
                      }`}>
                        {activity.type === 'watering' ? 
                          <Droplets size={16} className="text-blue-500" /> :
                         activity.type === 'light' ? 
                          <Sun size={16} className="text-amber-500" /> :
                          <Clock size={16} className="text-gray-500" />
                        }
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-gray-800">{activity.description}</p>
                        <div className="flex items-center mt-1">
                          <Calendar size={12} className="text-gray-400" />
                          <span className="text-xs text-gray-500 ml-1">{activity.date}</span>
                          <Clock size={12} className="text-gray-400 ml-2" />
                          <span className="text-xs text-gray-500 ml-1">{activity.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <WateringSchedule schedule={plant.wateringSchedule} />
              
              <EnvironmentChart data={plant.environmentData} />
            </div>
          )}
          
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800">Analytics</h2>
              <p className="text-gray-600">Detailed plant performance analytics will be displayed here.</p>
            </div>
          )}
          
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-800">Settings</h2>
              <p className="text-gray-600">Plant-specific settings will be displayed here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PlantDetails;
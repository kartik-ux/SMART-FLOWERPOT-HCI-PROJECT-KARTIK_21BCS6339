import React, { useState } from 'react';
import { Settings as SettingsIcon, Droplets, Sun, BellRing, RefreshCw, Save } from 'lucide-react';

const Settings: React.FC = () => {
  const [autoWatering, setAutoWatering] = useState(true);
  const [wateringThreshold, setWateringThreshold] = useState(30);
  const [autoLighting, setAutoLighting] = useState(true);
  const [lightingHours, setLightingHours] = useState({ start: '06:00', end: '18:00' });
  const [notifications, setNotifications] = useState(true);
  const [dataCollection, setDataCollection] = useState(15);
  const [darkMode, setDarkMode] = useState(false);
  const [timezone, setTimezone] = useState('America/Los_Angeles');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save settings to context/API
    console.log('Settings saved');
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
        <p className="text-gray-600">Configure your SmartPlanter system preferences</p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Watering Settings */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center mb-4">
            <Droplets size={20} className="text-blue-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-800">Watering Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-700">Automatic Watering</h3>
                <p className="text-xs text-gray-500">Enable or disable the auto-watering feature</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={autoWatering} 
                  onChange={() => setAutoWatering(!autoWatering)} 
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer 
                      peer-checked:after:translate-x-full peer-checked:after:border-white 
                      after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                      after:bg-white after:border-gray-300 after:border after:rounded-full 
                      after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Moisture Threshold</label>
              <p className="text-xs text-gray-500 mb-2">Water the plant when moisture drops below this level</p>
              <div className="flex items-center space-x-2">
                <input 
                  type="range" 
                  min="10" 
                  max="60" 
                  step="5"
                  value={wateringThreshold} 
                  onChange={(e) => setWateringThreshold(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm font-medium text-gray-700 min-w-[40px]">{wateringThreshold}%</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Lighting Settings */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center mb-4">
            <Sun size={20} className="text-amber-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-800">Lighting Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-700">Automatic Lighting</h3>
                <p className="text-xs text-gray-500">Enable or disable the auto-lighting feature</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={autoLighting} 
                  onChange={() => setAutoLighting(!autoLighting)} 
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer 
                      peer-checked:after:translate-x-full peer-checked:after:border-white 
                      after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                      after:bg-white after:border-gray-300 after:border after:rounded-full 
                      after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="lightStart" className="text-sm font-medium text-gray-700">Light On Time</label>
                <input 
                  id="lightStart"
                  type="time" 
                  value={lightingHours.start} 
                  onChange={(e) => setLightingHours({...lightingHours, start: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
                />
              </div>
              <div>
                <label htmlFor="lightEnd" className="text-sm font-medium text-gray-700">Light Off Time</label>
                <input 
                  id="lightEnd"
                  type="time" 
                  value={lightingHours.end} 
                  onChange={(e) => setLightingHours({...lightingHours, end: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Notification Settings */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center mb-4">
            <BellRing size={20} className="text-purple-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-800">Notification Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-700">Enable Notifications</h3>
                <p className="text-xs text-gray-500">Receive alerts for critical plant events</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={notifications} 
                  onChange={() => setNotifications(!notifications)} 
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer 
                      peer-checked:after:translate-x-full peer-checked:after:border-white 
                      after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                      after:bg-white after:border-gray-300 after:border after:rounded-full 
                      after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>
          </div>
        </div>
        
        {/* System Settings */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center mb-4">
            <SettingsIcon size={20} className="text-gray-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-800">System Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="dataInterval" className="text-sm font-medium text-gray-700">Data Collection Interval</label>
              <p className="text-xs text-gray-500 mb-2">How often to collect sensor data (in minutes)</p>
              <select 
                id="dataInterval"
                value={dataCollection} 
                onChange={(e) => setDataCollection(parseInt(e.target.value))}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
              >
                <option value={5}>Every 5 minutes</option>
                <option value={15}>Every 15 minutes</option>
                <option value={30}>Every 30 minutes</option>
                <option value={60}>Every hour</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="timezone" className="text-sm font-medium text-gray-700">Timezone</label>
              <select 
                id="timezone"
                value={timezone} 
                onChange={(e) => setTimezone(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-300 focus:ring focus:ring-green-200 focus:ring-opacity-50"
              >
                <option value="America/Los_Angeles">Pacific Time (US & Canada)</option>
                <option value="America/Denver">Mountain Time (US & Canada)</option>
                <option value="America/Chicago">Central Time (US & Canada)</option>
                <option value="America/New_York">Eastern Time (US & Canada)</option>
                <option value="UTC">UTC</option>
              </select>
            </div>
            
            <div className="flex items-center justify-between pt-2">
              <div>
                <h3 className="text-sm font-medium text-gray-700">Dark Mode</h3>
                <p className="text-xs text-gray-500">Switch between light and dark theme</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={darkMode} 
                  onChange={() => setDarkMode(!darkMode)} 
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer 
                      peer-checked:after:translate-x-full peer-checked:after:border-white 
                      after:content-[''] after:absolute after:top-[2px] after:left-[2px] 
                      after:bg-white after:border-gray-300 after:border after:rounded-full 
                      after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
              </label>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3">
          <button 
            type="button"
            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
          >
            <RefreshCw size={16} className="mr-2" />
            Reset to Defaults
          </button>
          <button 
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none"
          >
            <Save size={16} className="mr-2" />
            Save Settings
          </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
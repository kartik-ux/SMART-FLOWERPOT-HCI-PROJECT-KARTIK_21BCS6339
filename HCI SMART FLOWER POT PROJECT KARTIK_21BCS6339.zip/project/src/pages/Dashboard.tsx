import React, { useState } from 'react';
import PlantCard from '../components/PlantCard';
import { Plus, ChevronRight } from 'lucide-react';
import { usePlantContext } from '../context/PlantContext';
import WeatherWidget from '../components/WeatherWidget';
import StatusOverview from '../components/StatusOverview';
import AddPlantModal from '../components/AddPlantModal';

const Dashboard: React.FC = () => {
  const { plants } = usePlantContext();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-600">Monitor and manage your connected plants</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 
          text-white font-medium rounded-md transition-colors shadow-sm"
        >
          <Plus size={18} className="mr-2" />
          Add New Plant
        </button>
      </header>

      <StatusOverview />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <WeatherWidget />
        <div className="md:col-span-2 bg-white p-4 rounded-lg shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">System Performance</h2>
            <button className="text-green-600 hover:text-green-700 inline-flex items-center text-sm font-medium">
              View Details <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
          <div className="h-40 md:h-56 bg-gray-100 rounded flex items-center justify-center">
            <p className="text-gray-500">Performance chart here</p>
          </div>
        </div>
      </div>

      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Your Plants</h2>
          <button className="text-green-600 hover:text-green-700 inline-flex items-center text-sm font-medium">
            View All <ChevronRight size={16} className="ml-1" />
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {plants.map((plant) => (
            <PlantCard key={plant.id} plant={plant} />
          ))}
        </div>
      </section>

      <AddPlantModal 
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
};

export default Dashboard;
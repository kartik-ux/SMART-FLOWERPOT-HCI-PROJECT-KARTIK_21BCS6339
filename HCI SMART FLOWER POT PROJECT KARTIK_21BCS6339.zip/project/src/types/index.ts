export interface Plant {
  id: string;
  name: string;
  species: string;
  imageUrl: string;
  moisture: number;
  temperature: number;
  light: number;
  health: number;
  status: 'healthy' | 'warning' | 'critical';
  wateringStatus: 'auto' | 'manual';
  lastWatered: string;
  activities: Activity[];
  wateringSchedule: Schedule[];
  environmentData: EnvironmentData[];
}

export interface Activity {
  type: 'watering' | 'light' | 'system';
  description: string;
  date: string;
  time: string;
}

export interface Schedule {
  day: string;
  time: string;
  active: boolean;
  every?: string;
}

export interface EnvironmentData {
  day: string;
  moisture: number;
  temperature: number;
  light: number;
}